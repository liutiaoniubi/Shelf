# Shelf

把锁屏小组件行停靠到锁屏底部（快捷按钮上方），通知列表随之对齐。
针对 **iPhone 14 Pro Max / iOS 16.6.1 / arm64e / roothide** 配置。

---

## ✅ 环境确认：Relaxin 完全够用

**Relaxin 是完整越狱（roothide 架构，基于 Dopamine-roothide），原生注入 SpringBoard，锁屏 tweak 直接生效，不需要 Serotonin 之类的额外补丁。**

我之前担心的「roothide 不注入 SpringBoard」只发生在**独立的 RootHide Bootstrap 半越狱**上——那是另一回事。Relaxin 不属于那种情况，可以放心。

你的配置（iPhone 14 Pro Max / A16 / iOS 16.6.1）落在 Relaxin 支持区间 **16.5.1–17.3.1** 内，是官方点名的 A16 支持机型。

### 需要确认的两件事

1. **装了 ElleKit**（越狱基板）。不装的话任何 tweak 都加载不了。装完要**用户空间重启**才生效。
2. **装了 PreferenceLoader**。不装的话 Shelf 的设置面板不会出现在系统设置里（插件本身照常工作，只是没法调参数）。

两个都在 Relaxin 内置的 RootHide 源里，Sileo / Irisin 直接搜安装。

### 半不完美越狱，重启后要重新激活

Relaxin 是 semi-untethered：**每次重启手机，越狱失效回到未越狱状态**，插件还在但不运行。需要打开 Relaxin App 重新点一次越狱。不用连电脑。

所以如果你装完 Shelf 没效果，先确认是不是刚重启过还没重新越狱。

### 不需要 RootHide Patcher

我们直接编译成 `iphoneos-arm64e` 原生包，**不需要 Patcher 转换**。Patcher 只是给那些没适配 roothide 的老插件用的。

---

## 用 GitHub Actions 编译（无需 Mac）

workflow 已配好，用 GitHub 免费 macOS 构建机。

1. GitHub 新建空仓库（别勾初始化 README）
2. **Add file → Upload files**，把解压后的文件全拖进去
   - `.github` 是隐藏目录，macOS 访达 `Cmd+Shift+.` 才能看见，**务必确认它上传了**
3. 点 **Actions**，自动开始构建，等 3～8 分钟
4. 页面底部 **Artifacts** 下载 `Shelf-iphoneos-arm64e-roothide-deb`
5. 解压出 `.deb`，用 Sileo / Filza 安装

推 tag 会自动发 Release：

```bash
git tag v0.0.1 && git push origin v0.0.1
```

### 为什么必须用 roothide 的 Theos fork

官方 `theos/theos` **不支持** roothide scheme，只有 `roothide/theos` 支持。workflow 里 checkout 的已经是后者，不要改。

---

## 验证产物（别误判）

workflow 里 `Inspect package contents` 会打印 deb 内容。roothide 下你会看到：

```
./Library/MobileSubstrate/DynamicLibraries/Shelf.dylib
./Library/MobileSubstrate/DynamicLibraries/Shelf.plist
./Library/PreferenceBundles/ShelfPrefs.bundle/...
```

**看到 `/Library/...`（没有 `/var/jb`）是正确的，不是错误。** roothide 的包结构和有根包一致，dpkg 会自动把文件安装到随机的 `.jbroot-XXXXXXXX` 目录里。

随机路径形如：
```
/private/var/containers/Bundle/Application/.jbroot-CFB53A009C72E54B/
```
每次重新越狱都会变，所以**代码里绝不能硬编码任何越狱路径**——Shelf 只 hook 视图、不访问文件，没有这个隐患。

要确认 `Architecture` 字段是 `iphoneos-arm64e`。

---

## 与 Soko、AxsWidget 的差异

| | Soko | AxsWidget | Shelf |
|---|---|---|---|
| 语言 | Swift | ObjC/Logos | ObjC/Logos |
| 重排触发 | hook + 0.5s 轮询 | 纯事件驱动 | 纯事件驱动 |
| 位置计算 | AutoLayout 约束 | 改 frame/center | 绝对计算（以系统传入值为基准） |
| 防漂移 | system/applied 双值 | 未见 | 双值 + 回声检测 |
| PosterBoard | 有专门处理 | 无 | 过滤器包含（Relaxin 下大概率能注入） |

**关键改进**：位置从系统本次传入的 center/frame 出发绝对计算，不在已改过的值上叠加——这是「位置反复跑偏」的根因，Shelf 从结构上避免了。另有回声检测：系统把改过的值传回来时直接原样返回，不二次叠加。

**零定时器**：全靠 `didMoveToWindow` / `layoutSubviews` 驱动，锁屏静止时不跑任何代码。

---

## 安装

```bash
dpkg -i com.shelf.tweak_0.0.1_iphoneos-arm64e.deb
# 或丢进 Sileo / Filza
```

装完在「设置 → Shelf」调整，改开关／滑条立即生效（Darwin 通知触发重排），通常不用 respring。

卸载：`dpkg -r com.shelf.tweak`

Relaxin v0.5.4 起自带 **Irisin** 作为可选包管理器，Sileo 和 Irisin 都能装 deb，挑你顺手的。

---

## 调参

`Shelf.xm` 顶部：

- `ShelfWidgetGap()` — 小组件行与快捷按钮间距，默认 8pt
- `ShelfNotificationGap()` — 通知列表与小组件行间距，默认 10pt

---

## 已知风险 / 我无法验证的部分

1. **没有真机和 SDK，这份代码从未编译过**。首次构建大概率要修几处，看 Actions 报错改。
2. **`CSQuickActionsView` 类名**是从 Soko 源码推的，iOS 16.6.1 上的真实类名没有二进制佐证。装完组件没动，第一嫌疑就是它——用 cycript 打视图树确认。
3. **PosterBoard 能不能注入没有把握**。iOS 16 锁屏是 SpringBoard + PosterBoard 双进程渲染，Relaxin 是完整越狱，注入面比单纯的 Bootstrap 宽得多，但我没法确认 PosterBoard 一定在注入白名单里。Shelf.plist 的 Filter 写了两个，注不进的会静默跳过——**SpringBoard 那半边照常工作**，最坏情况只是偶尔有组件位置被重置。
4. **偏好面板**是唯一有链接风险的部分（`Preferences` 私有框架）。编译失败就在 `Makefile` 里注释掉 `SUBPROJECTS = prefs`，得到无面板的纯 tweak。
5. **不要和 Soko / AxsWidget 同装**，hook 点几乎完全重叠。

---

## 本地构建（有 Mac）

```bash
bash -c "$(curl -fsSL https://raw.githubusercontent.com/roothide/theos/master/bin/install-theos)"
export THEOS=~/theos
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide
```

---

## 许可

按你的需要自行处理。
